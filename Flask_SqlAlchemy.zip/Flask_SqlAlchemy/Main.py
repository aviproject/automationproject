from project import app

app.run(port=4040, threaded=True)

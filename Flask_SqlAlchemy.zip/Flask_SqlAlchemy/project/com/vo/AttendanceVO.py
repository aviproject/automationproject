from project import db


class AttendanceVO(db.Model):
    __tablename__ = 'attendancemaster'
    attendanceId = db.Column('attendanceId', db.Integer, primary_key=True, autoincrement=True)
    attendanceMonth = db.Column('attendanceMonth',db.String(20))
    attendanceFileName = db.Column('attendanceFileName', db.String(200))
    attendanceFilePath = db.Column('attendanceFilePath', db.String(200))

    def as_dict(self):
        return {
            'attendanceId': self.attendanceId,
            'attendanceMonth': self.attendanceMonth,
            'attendanceFileName': self.attendanceFileName,
            'attendanceFilePath': self.attendanceFilePath
        }

db.create_all()
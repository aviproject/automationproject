import os

from flask import request, render_template, redirect, url_for
from werkzeug.utils import secure_filename

from project import app
from project.com.dao.LetterTypeDAO import LetterTypeDAO
from project.com.vo.LetterTypeVO import LetterTypeVO
from project.com.controller.LoginController import adminLoginSession, adminLogoutSession

UPLOAD_FOLDER = 'project/static/adminResources/lettertype/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route('/admin/loadLetterType', methods=['GET'])
def adminLoadLetterType():
    try:
        if adminLoginSession() == 'admin':
            print("in load")
            return render_template('admin/addLetterType.html')
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)


@app.route('/admin/insertLetterType', methods=['POST'])
def adminInsertLetterType():
    try:
        if adminLoginSession() == 'admin':
            letterTypeVO = LetterTypeVO()
            letterTypeDAO = LetterTypeDAO()

            letterTypeName = request.form['letterTypeName']

            letterTypeDescription = request.form['letterTypeDescription']

            file = request.files['file']

            letterTypeFileName = secure_filename(file.filename)

            letterTypeFilePath = os.path.join(app.config['UPLOAD_FOLDER'])

            file.save(os.path.join(letterTypeFilePath, letterTypeFileName))

            letterTypeVO.letterTypeName = letterTypeName
            letterTypeVO.letterTypeDescription = letterTypeDescription

            letterTypeVO.letterTypeFileName = letterTypeFileName

            letterTypeVO.letterTypeFilePath = letterTypeFilePath.replace("project", "..")

            letterTypeDAO.insertLetterType(letterTypeVO)

            return redirect(url_for('adminViewLetterType'))

        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)


@app.route('/admin/viewLetterType', methods=['GET'])
def adminViewLetterType():
    try:
        if adminLoginSession() == 'admin':
            letterTypeDAO = LetterTypeDAO()
            letterTypeVOList = letterTypeDAO.viewLetterType()
            print("__________________", letterTypeVOList)
            return render_template('admin/viewLetterType.html', letterTypeVOList=letterTypeVOList)
        else:
            return redirect(url_for('adminLogoutSession'))


    except Exception as ex:
        print(ex)


@app.route('/admin/deleteLetterType', methods=['GET'])
def adminDeleteLetterType():
    try:
        if adminLoginSession() == 'admin':
            letterTypeVO = LetterTypeVO()
            letterTypeDAO = LetterTypeDAO()

            letterTypeVO.letterTypeId = request.args.get('letterTypeId')

            letterTypeList = letterTypeDAO.deleteLetterType(letterTypeVO)

            path = letterTypeList.letterTypeFilePath.replace("..", "project") + letterTypeList.letterTypeFileName

            os.remove(path)

            return redirect(url_for('adminViewLetterType'))
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)
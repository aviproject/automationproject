import os

from flask import request, render_template, redirect, url_for
from werkzeug.utils import secure_filename

from project import app
from project.com.dao.AttendanceDAO import AttendanceDAO
from project.com.vo.AttendanceVO import AttendanceVO
from project.com.controller.LoginController import adminLoginSession, adminLogoutSession

UPLOAD_FOLDER = 'project/static/adminResources/attendance/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route('/admin/loadAttendance', methods=['GET'])
def adminLoadAttendance():
    try:
        if adminLoginSession() == 'admin':
            print("in load")
            return render_template('admin/addAttendance.html')
        else:
            return redirect(url_for('adminLogoutSession'))
    except Exception as ex:
        print(ex)


@app.route('/admin/insertAttendance', methods=['POST'])
def adminInsertAttendance():
    try:
        if adminLoginSession() == 'admin':
            attendanceVO = AttendanceVO()
            attendanceDAO = AttendanceDAO()

            attendanceMonth = request.form['attendanceMonth']
            print(attendanceMonth)

            file = request.files['file']
            print(file)

            attendanceFileName = secure_filename(file.filename)
            print(attendanceFileName)

            attendanceFilePath = os.path.join(app.config['UPLOAD_FOLDER'])

            file.save(os.path.join(attendanceFilePath, attendanceFileName))

            attendanceVO.attendanceMonth = attendanceMonth
            attendanceVO.attendanceFileName = attendanceFileName
            attendanceVO.attendanceFilePath = attendanceFilePath.replace("project", "..")

            attendanceDAO.insertAttendance(attendanceVO)

            return redirect(url_for('adminViewAttendance'))

        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)


@app.route('/admin/viewAttendance', methods=['GET'])
def adminViewAttendance():
    try:
        if adminLoginSession() == 'admin':
            attendanceDAO = AttendanceDAO()
            attendanceVOList = attendanceDAO.viewAttendance()
            print("__________________", attendanceVOList)
            return render_template('admin/viewAttendance.html', attendanceVOList=attendanceVOList)

        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)


@app.route('/admin/deleteAttendance', methods=['GET'])
def adminDeleteAttendance():
    try:
        if adminLoginSession() == 'admin':
            attendanceVO = AttendanceVO()
            attendanceDAO = AttendanceDAO()

            attendanceVO.attendanceId = request.args.get('attendanceId')

            attendanceList = attendanceDAO.deleteAttendance(attendanceVO)

            path = attendanceList.attendanceFilePath.replace("..", "project") + attendanceList.attendanceFileName

            os.remove(path)

            return redirect(url_for('adminViewAttendance'))
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)

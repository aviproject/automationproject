from project import app
from flask import render_template, session



@app.route('/admin/viewComplaint')
def adminViewComplaint():
    return render_template('admin/viewComplaint.html')


@app.route('/admin/replyComplaint')
def adminReplyComplaint():
    return render_template('admin/replyComplaint.html')


@app.route('/admin/viewFeedback')
def adminViewFeedback():
    return render_template('admin/viewFeedback.html')

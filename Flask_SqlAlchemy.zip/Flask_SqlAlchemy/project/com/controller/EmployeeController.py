from project import app
from flask import redirect,render_template,request,url_for

from project.com.controller.LoginController import adminLoginSession,adminLogoutSession
from project.com.dao.DesignationDAO import DesignationDAO
from project.com.dao.DepartmentDAO import DepartmentDAO
from project.com.dao.EmployeeDAO import EmployeeDAO
from project.com.vo.EmployeeVO import EmployeeVO


@app.route('/admin/loadEmployee',methods=['get'])
def adminLoadEmployee():
    try:
        if adminLoginSession() == 'admin':
            designationDAO = DesignationDAO()
            designationVOList = designationDAO.viewDesignation()

            departmentDAO = DepartmentDAO()
            departmentVOList = departmentDAO.viewDepartment()

            return render_template('admin/addEmployee.html', departmentVOList=departmentVOList,
                                   designationVOList=designationVOList)
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)

@app.route('/admin/insertEmployee',methods=['post'])
def adminInsertEmployee():
    try:
        if adminLoginSession() == 'admin':
            employeeFirstName=request.form['employeeFirstName']
            employeeLastName=request.form['employeeLastName']
            employee_DepartmentId=request.form['employee_DepartmentId']
            employee_DesignationId=request.form['employee_DesignationId']
            employeeSalary=request.form['employeeSalary']
            employeeEmail=request.form['employeeEmail']
            employeeContactNo=request.form['employeeContactNo']
            employeeAddress=request.form['employeeAddress']
            employeeDOB=request.form['employeeDOB']
            employeeBloodGroup=request.form['employeeBloodGroup']
            employeeMaritalStatus=request.form['employeeMaritalStatus']

            employeeVO=EmployeeVO()
            employeeDAO=EmployeeDAO()

            employeeVO.employeeFirstName=employeeFirstName
            employeeVO.employeeLastName=employeeLastName
            employeeVO.employee_DepartmentId=employee_DepartmentId
            employeeVO.employee_DesignationId=employee_DesignationId
            employeeVO.employeeSalary=employeeSalary
            employeeVO.employeeEmail=employeeEmail
            employeeVO.employeeContactNo=employeeContactNo
            employeeVO.employeeAddress=employeeAddress
            employeeVO.employeeDOB=employeeDOB
            employeeVO.employeeBloodGroup=employeeBloodGroup
            employeeVO.employeeMaritalStatus=employeeMaritalStatus

            employeeDAO.insertEmployee(employeeVO)

            return redirect(url_for('adminViewEmployee'))
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)

@app.route('/admin/viewEmployee',methods=['get'])
def adminViewEmployee():
    try:
        if adminLoginSession() == 'admin':
            employeeDAO=EmployeeDAO()
            employeeVOList=employeeDAO.viewEmployee()

            return render_template('admin/viewEmployee.html',employeeVOList=employeeVOList)
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)

@app.route('/admin/deleteEmployee', methods=['GET'])
def adminDeleteEmployee():
    try:
        if adminLoginSession() == 'admin':
            employeeDAO = EmployeeDAO()
            employeeId = request.args.get('employeeId')

            employeeDAO.deleteEmployee(employeeId)

            return redirect(url_for('adminViewEmployee'))
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)


@app.route('/admin/editEmployee', methods=['GET'])
def adminEditEmployee():
    try:
        if adminLoginSession() == 'admin':
            employeeVO = EmployeeVO()
            employeeDAO = EmployeeDAO()
            departmentDAO = DepartmentDAO()
            designationDAO = DesignationDAO()

            employeeId = request.args.get('employeeId')

            employeeVO.employeeId = employeeId

            employeeVOList = employeeDAO.editEmployee(employeeVO)
            departmentVOList = departmentDAO.viewDepartment()
            designationVOList = designationDAO.viewDesignation()
            print("view designation")

            return render_template('admin/editEmployee.html',employeeVOList=employeeVOList,departmentVOList=departmentVOList,designationVOList=designationVOList)
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)

@app.route('/admin/updateEmployee', methods=['POST'])
def adminUpdateEmployee():
    try:
        if adminLoginSession() == 'admin':
            employeeId = request.form['employeeId']
            employeeFirstName = request.form['employeeFirstName']

            employeeLastName = request.form['employeeLastName']
            employee_DepartmentId = request.form['employee_DepartmentId']
            employee_DesignationId = request.form['employee_DesignationId']
            employeeSalary = request.form['employeeSalary']
            employeeEmail = request.form['employeeEmail']
            employeeContactNo = request.form['employeeContactNo']
            employeeAddress = request.form['employeeAddress']
            employeeDOB = request.form['employeeDOB']
            employeeBloodGroup = request.form['employeeBloodGroup']
            employeeMaritalStatus = request.form['employeeMaritalStatus']

            employeeVO = EmployeeVO()
            employeeDAO= EmployeeDAO()

            employeeVO.employeeId = employeeId
            employeeVO.employeeFirstName = employeeFirstName
            employeeVO.employeeLastName = employeeLastName
            employeeVO.employee_DepartmentId = employee_DepartmentId
            employeeVO.employee_DesignationId = employee_DesignationId
            employeeVO.employeeSalary = employeeSalary
            employeeVO.employeeEmail = employeeEmail
            employeeVO.employeeContactNo = employeeContactNo
            employeeVO.employeeAddress = employeeAddress
            employeeVO.employeeDOB = employeeDOB
            employeeVO.employeeBloodGroup = employeeBloodGroup
            employeeVO.employeeMaritalStatus = employeeMaritalStatus
            print("loandetailupdate")

            employeeDAO.updateEmployee(employeeVO)

            return redirect(url_for('adminViewEmployee'))
        else:
            return redirect(url_for('adminLogoutSession'))

    except Exception as ex:
        print(ex)




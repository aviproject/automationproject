from project import app
from flask import redirect,render_template,request,url_for

from project.com.controller.LoginController import adminLoginSession
from project.com.dao.DesignationDAO import DesignationDAO
from project.com.dao.DepartmentDAO import DepartmentDAO
from project.com.dao.EmployeeDAO import EmployeeDAO
from project.com.vo.EmployeeVO import EmployeeVO


@app.route('/admin/loadEmployee',methods=['get'])
def adminLoadEmployee():
    try:
        designationDAO = DesignationDAO()
        designationVOList = designationDAO.viewDesignation()

        departmentDAO = DepartmentDAO()
        departmentVOList = departmentDAO.viewDepartment()

        return render_template('admin/addEmployee.html', departmentVOList=departmentVOList,
                               designationVOList=designationVOList)

    except Exception as ex:
        print(ex)

from project.com.vo.LoginVO import LoginVO


class LoginDAO:
    def validateLogin(self, loginVO):
        loginList = LoginVO.query.filter_by(loginUsername=loginVO.loginUsername, loginPassword=loginVO.loginPassword,
                                            loginStatus=loginVO.loginStatus)

        return loginList

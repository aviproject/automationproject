from project import db
from project.com.vo.DepartmentVO import DepartmentVO
from project.com.vo.DesignationVO import DesignationVO
from project.com.vo.EmployeeVO import  EmployeeVO

class EmployeeDAO:

    def insertEmployee(self, EmployeeVO):
        db.session.add(EmployeeVO)
        db.session.commit()

    def viewEmployee(self):

        EmployeeList = db.session.query(EmployeeVO,DepartmentVO,DesignationVO).join(DepartmentVO,EmployeeVO.employee_DepartmentId ==DepartmentVO.departmentId).join(DesignationVO,EmployeeVO.employee_DesignationId ==DesignationVO.designationId).all()

        return EmployeeList

    def deleteEmployee(self, employeeId):

        employeeList = EmployeeVO.query.get(employeeId)

        db.session.delete(employeeList)

        db.session.commit()
from project import db
from project.com.vo.AttendanceVO import AttendanceVO

class AttendanceDAO:
    def insertAttendance(self, attendanceVO):
        db.session.add(attendanceVO)
        db.session.commit()

    def viewAttendance(self):

        attendanceVOList = AttendanceVO.query.all()

        return attendanceVOList

    def deleteAttendance(self, attendanceVO):

        attendanceList = attendanceVO.query.get(attendanceVO.attendanceId)

        db.session.delete(attendanceList)

        db.session.commit()

        return attendanceList
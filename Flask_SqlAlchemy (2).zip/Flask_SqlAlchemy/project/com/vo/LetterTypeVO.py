from project import db


class LetterTypeVO(db.Model):
    __tablename__ = 'lettertypemaster'
    letterTypeId = db.Column('letterTypeId', db.Integer, primary_key=True, autoincrement=True)
    letterTypeName = db.Column('letterTypeName', db.String(100))
    letterTypeDescription = db.Column('letterTypeDescription', db.String(100))
    letterTypeFileName = db.Column('letterTypeFileName', db.String(200))
    letterTypeFilePath = db.Column('letterTypeFilePath', db.String(200))

    def as_dict(self):
        return {
            'letterTypeId': self.letterTypeId,
            'letterTypeName': self.letterTypeName,
            'letterTypeDescription': self.letterTypeDescription,
            'letterTypeFileName': self.letterTypeFileName,
            'letterTypeFilePath': self.letterTypeFilePath
        }


db.create_all()
